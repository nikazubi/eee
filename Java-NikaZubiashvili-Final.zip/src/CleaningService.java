


public class CleaningService {
    static void cleanRoom(){
        System.out.println("Your Room was cleaned");
    }

    void cleanFullObject(){
        System.out.println("Full Bilding was cleaned");
    }


}
