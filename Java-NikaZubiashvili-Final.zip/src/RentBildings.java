

public interface RentBildings {
    // ინტერფეისი რომელის შვილები არიან ყველა ისეთი დაწესებულებები რომლებიც აქირავებენ ფართს
    double rentPrice();

}
